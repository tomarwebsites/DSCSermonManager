<?php
    // Create our post type

    add_action( 'init', 'create_post_type' );

    function create_post_type() {
            $args = array(
            'labels' => post_type_labels( 'Sermon' ),
            'public' => true,
            'has_archive' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => true,
            'capability_type' => 'post',
            'has_archive' => true,
            'hierarchical' => false,
            'menu_position' => null,
            'supports' => array('title'),
	    'register_meta_box_cb' => 'add_sermon_metaboxes' // This registers the metabox that we'll add later.
        );
     
            register_post_type( 'sermon', $args );
    }
     
    // A helper function for generating the labels
    function post_type_labels( $singular, $plural = '' )
    {
        if( $plural == '') $plural = $singular .'s';
       
        return array(
            'name' => _x( $plural, 'post type general name' ),
            'singular_name' => _x( $singular, 'post type singular name' ),
            'add_new' => __( 'Add New' ),
            'add_new_item' => __( 'Add New '. $singular ),
            'edit_item' => __( 'Edit '. $singular ),
            'new_item' => __( 'New '. $singular ),
            'view_item' => __( 'View '. $singular ),
            'search_items' => __( 'Search '. $plural ),
            'not_found' =>  __( 'No '. $plural .' found' ),
            'not_found_in_trash' => __( 'No '. $plural .' found in Trash' ),
            'parent_item_colon' => ''
        );
    }
     
//add filter to ensure the text Sermon, or sermon, is displayed when user updates a sermon

    add_filter('post_updated_messages', 'post_type_updated_messages');

    function post_type_updated_messages( $messages ) {
            global $post, $post_ID;
     
            $messages['sermon'] = array(
                    0 => '', // Unused. Messages start at index 1.
                    1 => sprintf( __('Sermon updated. <a href="%s">View sermon</a>'), esc_url( get_permalink($post_ID) ) ),
                    2 => __('Custom field updated.'),
                    3 => __('Custom field deleted.'),
                    4 => __('Sermon updated.'),
                    /* translators: %s: date and time of the revision */
                    5 => isset($_GET['revision']) ? sprintf( __('Semon restored to revision from %s'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
                    6 => sprintf( __('Sermon published. <a href="%s">View sermon</a>'), esc_url( get_permalink($post_ID) ) ),
                    7 => __('Sermon saved.'),
                    8 => sprintf( __('Sermon submitted. <a target="_blank" href="%s">Preview sermon</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
                    9 => sprintf( __('Sermon scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview sermon</a>'),
                    // translators: Publish box date format, see php.net/date
                    date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( get_permalink($post_ID) ) ),
                    10 => sprintf( __('Sermon draft updated. <a target="_blank" href="%s">Preview sermonSermon</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID)))),
            );
            return $messages;
    }

//Custom Taxonomies
 
add_action( 'init', 'create_speakers' );

function create_speakers() {
 $labels = array(
    'name' => _x( 'Speakers', 'taxonomy general name' ),
    'singular_name' => _x( 'Speaker', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Speakers' ),
    'all_items' => __( 'All Speakers' ),
    'parent_item' => __( 'Parent Speaker' ),
    'parent_item_colon' => __( 'Parent Speaker:' ),
    'edit_item' => __( 'Edit Speaker' ),
    'update_item' => __( 'Update Speaker' ),
    'add_new_item' => __( 'Add New Speaker' ),
    'new_item_name' => __( 'New Speaker' ),
  );
 
  register_taxonomy('speaker','sermon',array(
    'hierarchical' => false,
    'labels' => $labels,
    "public" => "true"
  ));
}

add_action( 'init', 'create_series' );

function create_series() {
 $labels = array(
    'name' => _x( 'Series', 'taxonomy general name' ),
    'singular_name' => _x( 'Series', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Series' ),
    'all_items' => __( 'All Series' ),
    'parent_item' => __( 'Parent Series' ),
    'parent_item_colon' => __( 'Parent Series:' ),
    'edit_item' => __( 'Edit Series' ),
    'update_item' => __( 'Update Series' ),
    'add_new_item' => __( 'Add New Series' ),
    'new_item_name' => __( 'New Series' ),
  );
 
  register_taxonomy('series','sermon',array(
    'hierarchical' => false,
    'labels' => $labels,
    "public" => "true"
  ));
}

add_action( 'init', 'create_books' );

function create_books() {
 $labels = array(
    'name' => _x( 'Books', 'taxonomy general name' ),
    'singular_name' => _x( 'Book', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Books' ),
    'all_items' => __( 'All Books' ),
    'parent_item' => __( 'Parent Book' ),
    'parent_item_colon' => __( 'Parent Book:' ),
    'edit_item' => __( 'Edit Book' ),
    'update_item' => __( 'Update Book' ),
    'add_new_item' => __( 'Add New Book' ),
    'new_item_name' => __( 'New Book' ),
  );
 
  register_taxonomy('book','sermon',array(
    'hierarchical' => false,
    'labels' => $labels,
    "public" => "true"
  ));

}// Create Meta boxes
 
function add_sermon_metaboxes() {
    add_meta_box('sermon_info', 'Sermon Information', 'sermon_info', 'sermon', 'normal', 'high');
}
 
// Sermon Meta Box
 
function sermon_info() {
    global $post;
 
// Noncename needed to verify where the data originated
    echo '<input id="sermonmeta_noncename" name="sermonmeta_noncename" type="hidden" value="' .     wp_create_nonce( plugin_basename(__FILE__) ) . '" />';

// Get the data if its already been entered
    $date = get_post_meta($post->ID, '_date', true);
    $service = get_post_meta($post->ID, '_service', true);

    $textbook = get_post_meta($post->ID, '_textbook', true);
    $textstartchapt = get_post_meta($post->ID, '_textstartchapt', true);
    $textstartverse = get_post_meta($post->ID, '_textstartverse', true);
    $textendchapt = get_post_meta($post->ID, '_textendchapt', true);
    $textendverse = get_post_meta($post->ID, '_textendverse', true);
 
    // Echo out the field
    echo '<strong>Date</strong><br /><em>Enter the Date the sermon was preached.</em>';
    echo '<input class="widefat" name="_date" type="text" value="' . $date  . '" />';

    echo '<strong>Service</strong><br /><em>AM/PM?</em>';
    echo '<input class="widefat" name="_service" type="text" value="' . $service  . '" />';

    echo '<strong>Book</strong><br /><em>Enter Book...</em>';
    echo '<input class="widefat" name="_textbook" type="text" value="' . $textbook  . '" />';

    echo '<strong>From, Chapter</strong><br /><em>Enter Start Chapter</em>';
    echo '<input class="widefat" name="_textstartchapt" type="text" value="' . $textstartchapt  . '" />';

    echo '<strong>& Verse</strong><br /><em>Enter Start Verse</em>';
    echo '<input class="widefat" name="_textstartverse" type="text" value="' . $textstartverse  . '" />';
    
    echo '<strong>To, Chapter</strong><br /><em>Enter End Chapter</em>';
    echo '<input class="widefat" name="_textendchapt" type="text" value="' . $textendchapt  . '" />';

    echo '<strong>& Verse</strong><br /><em>Enter End Verse</em>';
    echo '<input class="widefat" name="_textendverse" type="text" value="' . $textendverse  . '" />';
}
 
// Save the Meta box Data
 
function save_sermon_meta($post_id, $post) {
 
    // verify this came from the our screen and with proper authorization,
    // because save_post can be triggered at other times
    if ( !wp_verify_nonce( $_POST['sermonmeta_noncename'], plugin_basename(__FILE__) )) {
    return $post->ID;
    }
 
    // Is the user allowed to edit the post or page?
    if ( !current_user_can( 'edit_post', $post->ID ))
        return $post->ID;
 
    // OK, we're authenticated: we need to find and save the data
    // We'll put it into an array to make it easier to loop though.
 
    $sermon_meta['_date'] = $_POST['_date'];
    $sermon_meta['_service'] = $_POST['_service'];
    $sermon_meta['_textbook'] = $_POST['_textbook'];
    $sermon_meta['_textstartchapt'] = $_POST['_textstartchapt'];
    $sermon_meta['_textstartverse'] = $_POST['_textstartverse'];
    $sermon_meta['_textendchapt'] = $_POST['_textendchapt'];
    $sermon_meta['_textendverse'] = $_POST['_textendverse'];
 
    // Add values of $sermon_meta as custom fields
 
    foreach ($sermon_meta as $key => $value) { // Cycle through the $sermon_meta array!
        if( $post->post_type == 'revision' ) return; // Don't store custom data twice
        $value = implode(',', (array)$value); // If $value is an array, make it a CSV (unlikely)
        if(get_post_meta($post->ID, $key, FALSE)) { // If the custom field already has a value
            update_post_meta($post->ID, $key, $value);
        } else { // If the custom field doesn't have a value
            add_post_meta($post->ID, $key, $value);
        }
        if(!$value) delete_post_meta($post->ID, $key); // Delete if blank
    }
 
}
add_action('save_post', 'save_sermon_meta', 1, 2); // save the custom fields

add_action("manage_posts_custom_column",  "portfolio_custom_columns");
add_filter("manage_edit-sermon_columns", "sermon_edit_columns");
 
function sermon_edit_columns($columns){
  $columns = array(
    "cb" => "<input type=\"checkbox\" />",
    "title" => "Sermon Title",
    "pdate" => "Preached",
    "service" => "Service",
    "series" => "Series",
    "speaker" => "Speaker",
    "book" =>"Book",
    "date" => "Date",
  );
 
  return $columns;
}



add_action ('init','WPsermon_Init');


function portfolio_custom_columns($column){
  global $post;
 
  switch ($column) {
    case "pdate":
	echo get_post_meta($post->ID, '_date', true);
	break;
    case "service":
	echo get_post_meta($post->ID, '_service', true);
	break;
    case "series":
	echo get_the_term_list($post->ID, 'series', '', ', ','');
	break;
    case "speaker":
	echo get_the_term_list($post->ID, 'speaker', '', ', ','');
	break;
    case "book":
	echo get_the_term_list($post->ID, 'book', '', ', ','');
	break;
    case "book":
	echo get_the_term_list($post->ID, 'date', '', ', ','');
	break;
  }
}

function kriesi_pagination($pages = '', $range = 2)
{  
     $showitems = ($range * 2)+1;  

     global $paged;
     if(empty($paged)) $paged = 1;

     if($pages == '')
     {
         global $wp_query;
         $pages = $wp_query->max_num_pages;
         if(!$pages)
         {
             $pages = 1;
         }
     }   

     if(1 != $pages)
     {
         echo "<div class='pagination'>";
         if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<a href='".get_pagenum_link(1)."'>&laquo;</a>";
         if($paged > 1 && $showitems < $pages) echo "<a href='".get_pagenum_link($paged - 1)."'>&lsaquo;</a>";

         for ($i=1; $i <= $pages; $i++)
         {
             if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
             {
                 echo ($paged == $i)? "<span class='current'>".$i."</span>":"<a href='".get_pagenum_link($i)."' class='inactive' >".$i."</a>";
             }
         }

         if ($paged < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($paged + 1)."'>&rsaquo;</a>";  
         if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($pages)."'>&raquo;</a>";
         echo "</div>\n";
     }
}

add_filter('query_vars', 'parameter_queryvars' );
function parameter_queryvars( $qvars )
{
$qvars[] = 'serieslug';
return $qvars;
}

// Insert Widget Here

function WPSermon_Recent_Widget()
{
query_posts(array(
	'post_type' => 'sermon',
	'showposts' => 2,
    'post_status' => 'publish',
	'orderby' => 'meta_value',
	'meta_key' => '_date',
	'order' => 'dsc', 
));

echo '<h2>Recent Sermons</h2><ul>';

while (have_posts()) : the_post();
	echo '<li><a title="';
	echo the_title();
	echo '" href="';
	echo the_permalink();
	echo '">';
	echo the_title();
	echo '</a></li>';
endwhile;
echo '</ul>';
}

function WPSermon_Recent_Widget_Control()
{
// get saved options

$options = get_option('wp_recent_sermon');

// handle user input

if ($_POST["sermon_submit"])
{
	$options['rs_title']=strip_tags(stripslashes($_POST["rs_title"]));
	update_option('wp_recent_sermon', $options);
}
$title = $options['rs_title'];

// print out widget control
echo '<p><label for="rstitle">Title: <input name="rs_title" type="text" value="';
echo $title;
echo '"/></label><input type="hidden" id="sermon_submit" value"1" />';


}


function WPSermon_Init()
{
register_sidebar_widget('Recent Sermons', 'WPSermon_Recent_Widget');
register_widget_control('Recent Sermons', 'WPSermon_Recent_Widget_Control');
}

function add_custom_query_var( $vars ){
  $vars[] = 'thisseries';
  return $vars;
}
add_action( 'query_vars', 'add_custom_query_var' );

function orderbyreplace($orderby) {
    return str_replace('menu_order',
                       'mt1.meta_value, mt2.meta_value',
                       $orderby);
}

// filter for tags (as a taxonomy) with comma
//  replace '--' with ', ' in the output - allow tags with comma this way

if(!is_admin()){ // make sure the filters are only called in the frontend
	
	$custom_taxonomy_type = 'series';	// here goes your taxonomy type
	
	function comma_taxonomy_filter($tag_arr){
		global $custom_taxonomy_type;
		$tag_arr_new = $tag_arr;
		if($tag_arr->taxonomy == $custom_taxonomy_type && strpos($tag_arr->name, '--')){
			$tag_arr_new->name = str_replace('--',', ',$tag_arr->name);
		}
		return $tag_arr_new;	
	}
	add_filter('get_'.$custom_taxonomy_type, comma_taxonomy_filter);
	
	function comma_taxonomies_filter($tags_arr){
		$tags_arr_new = array();
		foreach($tags_arr as $tag_arr){
			$tags_arr_new[] = comma_taxonomy_filter($tag_arr);
		}
		return $tags_arr_new;
	}
	add_filter('get_the_taxonomies',	comma_taxonomies_filter);
	add_filter('get_terms', 			comma_taxonomies_filter);
	add_filter('get_the_terms',			comma_taxonomies_filter);
}
?>