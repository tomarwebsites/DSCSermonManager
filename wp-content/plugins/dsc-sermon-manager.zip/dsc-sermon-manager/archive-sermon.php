<?php
get_header();
?>
<div class="wrap">
    <div id="Primary">
        <main id="Main" role="Main">
		<div class="sermoncontent">
			<h1 class="page-title">Next Sunday</h1>                     
<?php //echo time();
                        global $post;
                        $args = ['post_type' => 'sermon',
                                'post_status'  => 'publish',
                                'numberposts'  => 2,
                                'meta_query' => array(
                                    array(
                                        'key' => '_date',
                                        'value' => time()-1,
                                        'compare' => '>'
                                        ),  
                                    ),
                                'orderby' => 'meta_value',
                                'order' => 'asc'
                                ];

                                $futureposts = get_posts( $args );
                                foreach ( $futureposts as $post ) : setup_postdata( $post ); ?>
                        
                             <div class="sermonlist">
<!-- Sermon Date/Service -->
 				<div class="sermondate">
<?php                               echo my_sermon_date($post->ID);?>
                                </div>
				<div class="sermontitle">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </div>
                                <div class="sermonspeaker">
<?php                               echo get_the_term_list($post->ID, 'speaker', ''); ?>
                                </div>
                             </div>
<?php                        endforeach; 

                        wp_reset_postdata();?>
                
			<h3>Most Recent Sermons</h3>
				<div class="sermonheader">
					<div class="sermondateH">Date</div>
					<div class="sermontitleH">Title (Click 'title' to listen online)</div>
					<div class="sermontextH">Book/Chapter/Verse</div>
					<div class="sermonseriesH">Series</div>
					<div class="sermonspeakerH">Speaker</div>
				</div><!-- sermonheader -->
<!-- Main Loop, START -->
<?php
                        $args2 = array(
					'post_type' => 'sermon',
					'post_status' => 'publish',
					'orderby' => 'meta_value',
                                        'order' => 'dsc',
					'paged' => $paged,
					'posts_per_page' => 8,
                                        'meta_query' => array(
                                                array(
                                                    'key' => '_date',
                                                    'value' => time(),
                                                    'compare' => '<'
                                                    )
                                                )

					);
                                
                                $pastposts = get_posts($args2);
                                
				//$wp_query2 = new WP_Query($args);?>
<?php
				//if (have_posts()) : ?>
<?php
					//while (have_posts()) : the_post();
                                    foreach ( $pastposts as $post ) : setup_postdata( $post );?>

						<div class="sermonlist">
<!-- Sermon Date/Service -->
 							<div class="sermondate">
<?php                                                       $date = date('m/d/Y h:i:s a', time());
                                                            // $timezone = date_default_timezone_get();
                                                            //echo "The current server timezone is: " . $timezone;
                                                            
                                                            echo my_sermon_date($post->ID);
 ?>
                    					</div><!—End “sermondate" -->
<!-- Sermon Title -->
							<div class="sermontitle">
								<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a>
							</div><!-- End “sermontitle” -->
<!-- Sermon Text -->
							<div class="sermontext">
<?php								 echo my_sermon_text($post->ID);?>
							</div><!-- End “sermontext” -->
<!-- Sermon Series -->
							<div class="sermonseries">
<?php								echo get_the_term_list($post->ID, 'series', ''); ?>
							</div><!-- End “sermonseries” -->
<!-- Sermon Speaker -->
							<div class="sermonspeaker">
<?php
								echo get_the_term_list($post->ID, 'speaker', ''); ?>
							</div><!-- End “sermonspeaker” -->
						</div><!-- End "sermonlist" -->
                                    <?php endforeach; 

                                    wp_reset_postdata();
					//endwhile; ?>
<?php
				//endif; ?>

<!-- SEARCH... -->
				<div class="sermonlist">
					<h2>
						Click <a href="<?php bloginfo('url');?>/speaker/john-samuel/" rel="tag">HERE</a> for more sermons by our Senior Minister: John Samuel
					</h2>		 			
			</div><!-- End "sermonlist" -->
<!-- PODCASTS -->
			<div class="sermonlist">
				<h2>
					Subscribe to our podcasts...
				</h2>
				<p>
					<img src='http://sermons.dukestreetchurch.com/images/xmlrssfeed.gif' border='0' align='absmiddle' alt='Podcast'>
					<a title="Morning Podcast" href="http://phobos.apple.com/WebObjects/MZStore.woa/wa/viewPodcast?id=199320119 " target="_blank">
						Morning Sermons
					</a>
				</p>
				<p>
					<img src='http://sermons.dukestreetchurch.com/images/xmlrssfeed.gif' border='0' align='absmiddle' alt='Podcast'>
					<a title="Evening Podcast" href="http://phobos.apple.com/WebObjects/MZStore.woa/wa/viewPodcast?id=269412447 " target="_blank">
						Evening Sermons
					</a>
				</p>
			</div><!-- sermonlist -->

<?php
	function get_terms_dropdown($taxonomies, $args, $taxname) {
		$myterms = get_terms($taxonomies, $args);
		$output = "<select name=$taxname>";
		foreach ($myterms as $term) {
			$root_url = get_bloginfo('url');
			$term_taxonomy = $term->taxonomy;
			$term_slug = $term->slug;
			$term_name = $term->name;
			$link = $term_slug;
			$output .="<option value='" . $link . "'>" . $term_name . " (" . $term->count . ") </option>";
			}
		$output .="</select>";
		return $output;
	} ?>
									<div class="sermonlist">
										<div class="sermontextdd">
											<h4>...by BOOK</h4>
											<form action="<?php bloginfo('url'); ?>" method="get">
<?php
												$taxonomies = array('book');
			   									$args = array('orderby' => 'name', 'hide_empty' => true);
												$select = get_terms_dropdown($taxonomies, $args, 'book');
												$select = preg_replace("#<select([^>]*)>#", "<select$1 onchange='return this.form.submit()'><option value='0'>Select BOOK</option>", $select);
												echo $select;?>
												<noscript><div><input type="submit" value="Näytä" /></div></noscript>
											</form>
										</div><!-- sermontextdd -->
										<div class="sermontextdd">
											<h4>...by SERIES</h4>
											<form action="<?php bloginfo('url'); ?>" method="get">
<?php
												$taxonomies = array('series');
												$args = array('orderby' => 'name', 'hide_empty' => true);
												$select = get_terms_dropdown($taxonomies, $args, 'series');
												$select = preg_replace("#<select([^>]*)>#", "<select$1 onchange='return this.form.submit()'><option value='0'>Select SERIES</option>", $select);
												echo $select;
?>
												<noscript><div><input type="submit" value="Näytä" /></div></noscript>
											</form>
										</div><!-- sermontextdd -->
										<div class="sermontextdd">
											<h4>...by SPEAKER</h4>
											<form action="<?php bloginfo('url'); ?>" method="get">
<?php		
												$taxonomies = array('speaker');
												$args = array('orderby' => 'name', 'hide_empty' => true);
												$select = get_terms_dropdown($taxonomies, $args, 'speaker');
												$select = preg_replace("#<select([^>]*)>#", "<select$1 onchange='return this.form.submit()'><option value='0'>Select SPEAKER</option>", $select);
												echo $select;
?>
												<noscript><div><input type="submit" value="Näytä" /></div></noscript>
											</form>

										</div><!-- sermontextdd -->


									</div><!-- End "sermonlist"-->

						</div><!-- End "sermoncontent" -->
</main>
</div>
	</div><!-- End "page Content" -->
</div><!-- End "content_wrapper"-->
<?php
get_footer();?>