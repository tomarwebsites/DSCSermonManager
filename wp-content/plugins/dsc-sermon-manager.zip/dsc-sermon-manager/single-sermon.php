<?php
	get_header(); // Loads the header.php template?>

<div class="wrap">
<div id="Primary">
<main id="Main" role="Main">

	<h3>
		<?php the_title(); echo "<br>".get_the_term_list($post->ID, 'series', 'from the series: '); ?>		
	</h3>
<?php	
				if (have_posts ()) : ?>
<?php
					while (have_posts ()) : the_post(); ?>
<!-- Speaker -->
<?php							$terms = get_the_terms($post->ID, 'speaker');

							// print_r(array_values($terms));


							$count = count($terms);
							if ($count > 0) {
								foreach ($terms as $term) {
									$imagename = $term->name;
									$termid = $term->term_id;
								}
							}

							// image id is stored as term meta
							$image_id = get_term_meta($termid, 'image', true );

							// image data stored in array, second argument is which image size to retrieve
							$image_data = wp_get_attachment_image_src( $image_id, 'full' );

							// image url is the first item in the array (aka 0)
							$image = $image_data[0];

							if ( ! empty( $image ) ) {
    								echo '<img src="' . esc_url( $image ) . '" /><br>';

}
							


							$speakername = str_replace(" ", "", $imagename);
							$speakerimage = "http://www.dukestreetchurch.com/audio/images/" . strtolower($speakername) . ".jpg";
					
							echo get_the_term_list($post->ID, 'speaker', ''); ?>
<!-- Date/Service Preached -->
							<h3>
<?php								// echo my_sermon_text($post->ID);?>
							</h3>
<!-- Media Player/Links -->
<?php							$audiofile = "http://www.dukestreetchurch.com/audio/".$sermon_year.$sermon_month.$sermon_day.$sermon_service.".mp3";
							echo '<audio autoplay controls><source src="' . $audiofile . '" type="audio/ogg">Your browser does not support the audio element.</audio>';
							echo '<br/><h3><a href="'.$audiofile.'">Right Click to download the mp3</a></h3>';

?>
<?php 					endwhile;
 				//else :					
					// _e('Not Found');						
				endif;?>
<!-- Bible Passage -->
<?php					$messages_text_book = get_post_meta($post->ID, '_textbook', true);
					$messages_text_start_chapter = get_post_meta($post->ID, '_textstartchapt', true);
					$messages_text_start_verse = get_post_meta($post->ID, '_textstartverse', true);
					$messages_text_end_chapter = get_post_meta($post->ID, '_textendchapt', true);
					$messages_text_end_verse = get_post_meta($post->ID, '_textendverse', true);
// Book
					if ($messages_text_book == "") {
						$bgref .="&nbsp";
					} else {
						$bgref .="$messages_text_book";
					}
// Start Chapt
					if ($messages_text_start_chapter == "") {
						$bgref .="";
					} else {
						$bgref .=" $messages_text_start_chapter:";
					}
// Start Verse
					if ($messages_text_start_verse == "") {
						$bgref .="\r";
					} else {
						$bgref .="$messages_text_start_verse";
					}
// End Chapt
					if ($messages_text_end_chapter == "") {
						$bgref .="";
					} else {
						$bgref .=" - $messages_text_end_chapter:";
					}
// End Verse
					if ($messages_text_end_verse == "") {
						$bgref .="&nbsp";
					} else {
						if ($messages_text_end_chapter == "") {
							$bgref .="-$messages_text_end_verse";
						} else {
							$bgref .="$messages_text_end_verse";
						}
						$linkref = $bgref;
					}

					$dsc_version = esc_attr(get_option('dsc_bible_Version'));
					$dsc_language = get_option('dsc_bible_language');

					$token = 'R93AGw3zOpTdmdenbdzznnLmyRxGjBT616td69xB';
					
					$url = 'https://bibles.org/v2/passages.xml?q[]='.$messages_text_book.'+'.$messages_text_start_chapter.':'.$messages_text_start_verse.'-'.$messages_text_end_verse.'&version='.$dsc_language.'-'.$dsc_version;
					$ch = curl_init();
// Set the URL
					curl_setopt($ch, CURLOPT_URL, $url);
// don't verify SSL certificate
					curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
// Return the contents of the response as a string
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
// Follow redirects
					curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
// Set up authentication
					curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
					curl_setopt($ch, CURLOPT_USERPWD, "$token:X");
// Do the request
					$response = curl_exec($ch);
					curl_close($ch);
// Parse the XML into a SimpleXML object
					$xml = new SimpleXMLElement($response);
// Print the passage
					print '<h3>'.($xml->search->result->passages->passage[0]->display).'</h3>';
					print ($xml->search->result->passages->passage[0]->text);					
					print ($xml->search->result->passages->passage[0]->copyright);

					echo '<h3>Show me more sermons...</h3>';
					
					echo get_the_term_list($post->ID, 'speaker', 'by: ').'<br/>'; 
					echo get_the_term_list($post->ID, 'series', 'from: ').'<br/>'; 
					echo get_the_term_list($post->ID, 'book', 'from: ').'<br/>';
?>
</main>
</div>
</div>

<?php get_footer(); // Loads the footer.php template ?>